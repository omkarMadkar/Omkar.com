
import gmail.gmail;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */

/**
 *
 * @author omkar
 */
public class Creat_Account extends javax.swing.JInternalFrame {

    /**
     * Creates new form Creat_Account
     */
    public Creat_Account() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        loginProfile = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txt_name3 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        btw = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txt_name4 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txt_name5 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txt_name6 = new javax.swing.JTextField();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(loginProfile, new org.netbeans.lib.awtextra.AbsoluteConstraints(328, 43, -1, 150));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 31)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setText("Creat Account");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 190, 240, -1));

        txt_name3.setToolTipText("Please Enter Addhar No");
        txt_name3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_name3ActionPerformed(evt);
            }
        });
        jPanel1.add(txt_name3, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 460, 220, 30));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setText("Addhar no.");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 460, 100, 20));

        btw.setFont(new java.awt.Font("Segoe UI Symbol", 1, 14)); // NOI18N
        btw.setText("Submit");
        btw.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btw.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btwMouseClicked(evt);
            }
        });
        btw.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btwActionPerformed(evt);
            }
        });
        jPanel1.add(btw, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 520, 95, 39));

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assest/close-btn.png"))); // NOI18N
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(454, 13, 24, 23));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assest/verify-profile.png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 80, 100, 110));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setText("Name");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 280, 60, 20));

        txt_name4.setToolTipText("Please Enter Name");
        txt_name4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_name4ActionPerformed(evt);
            }
        });
        jPanel1.add(txt_name4, new org.netbeans.lib.awtextra.AbsoluteConstraints(141, 275, 220, 30));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel6.setText("Phone");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 340, 60, 20));

        txt_name5.setToolTipText("Please Enter Phone .No");
        txt_name5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_name5ActionPerformed(evt);
            }
        });
        jPanel1.add(txt_name5, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 340, 220, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setText("E-mail");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 400, 60, 20));

        txt_name6.setToolTipText("Please Enter Email_id");
        txt_name6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_name6ActionPerformed(evt);
            }
        });
        jPanel1.add(txt_name6, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 400, 220, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 220, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 615, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 41, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_name6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_name6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_name6ActionPerformed

    private void txt_name5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_name5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_name5ActionPerformed

    private void txt_name4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_name4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_name4ActionPerformed

    private void btwActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btwActionPerformed
        //   JOptionPane.showMessageDialog(null, "Account Created Successfully");
     
        if((txt_name4.getText().equals("") )&& (txt_name4.getText().equals("")))
        {
            JOptionPane.showMessageDialog(null, "PLEASE FILL ALL INFORMATION");
             JOptionPane.showMessageDialog(null, "Account NOT Created ");
        }
        else
        {
          
//Email start
         boolean b;
        String to=txt_name6.getText();
        gmail g =new gmail();
        b=g.sendemail("WELCOME TO ASOD BANK LOGIN"," ACCOUNT CREATED SUCCESSFULLY",to);
        if(b)
        {
            JOptionPane.showMessageDialog(null, "EMAIL SENT SUCCESSFULLY");
        }
        else
        {
            JOptionPane.showMessageDialog(null, "EMAIL NOT SENT");
        }
     
//Email end
            JOptionPane.showMessageDialog(null, "Account Created Successfully");
        }
    }//GEN-LAST:event_btwActionPerformed

    private void btwMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btwMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btwMouseClicked

    private void txt_name3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_name3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_name3ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btw;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel loginProfile;
    private javax.swing.JTextField txt_name3;
    private javax.swing.JTextField txt_name4;
    private javax.swing.JTextField txt_name5;
    private javax.swing.JTextField txt_name6;
    // End of variables declaration//GEN-END:variables
}
