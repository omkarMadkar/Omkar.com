/*


   internal_create menu=new  internal_create();
        deskpane.removeAll();
        deskpane.add(menu).setVisible(true);
*/
package gmail;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
/**
 *
 * @author admin
 */
public class gmail {
 public static String username="xc.omkarmadkar027@gmail.com";
 public static String password="uapxcxiyvdbtmtnn";
  
  
   public static boolean sendemail(String subject,String msg,String to)
   {
       boolean b=false;
  
           Properties pros=new Properties();
           pros.put("mail.smtp.auth","true");
           pros.put("mail.smtp.ssl.trust", "smtp.gmail.com");
           pros.put("mail.smtp.starttls.enable", "true");
           pros.put("mail.smtp.host","smtp.gmail.com");
           pros.put("mail.smtp.ssl.protocols", "TLSv1.2");
           
           
           pros.put("mail.smtp.port", 587);
           
           Session session=Session.getInstance(pros, new javax.mail.Authenticator() {
          @Override
          protected javax.mail.PasswordAuthentication getPasswordAuthentication(){
              
          return new javax.mail.PasswordAuthentication(username,password);
          }
           });
           
           
           
       
       try{
           Message message=new MimeMessage(session);
          
           message.setFrom(new InternetAddress(username));
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(to));
           message.setSubject(subject);
           message.setText(msg);
           Transport.send(message);
          b=true;
           
           
           
           
       }catch(Exception e){
           System.out.println("THE  EXCEPTION IS "+e);
       }
       return b;
}
   
   public static boolean sendemail(String subject,String msg,String to,String from,String pass)
   {
       boolean b=false;
       username=from;
       password=pass;
           Properties pros=new Properties();
           pros.put("mail.smtp.auth","true");
           pros.put("mail.smtp.ssl.trust", "smtp.gmail.com");
           pros.put("mail.smtp.starttls.enable", "true");
           pros.put("mail.smtp.host","smtp.gmail.com");
           pros.put("mail.smtp.ssl.protocols", "TLSv1.2");
           
           
           pros.put("mail.smtp.port", 587);
           
           Session session=Session.getInstance(pros, new javax.mail.Authenticator() {
          @Override
          protected javax.mail.PasswordAuthentication getPasswordAuthentication(){
              
          return new javax.mail.PasswordAuthentication(from,pass);
          }
           });
           
           
           
       
       try{
           Message message=new MimeMessage(session);
          
           message.setFrom(new InternetAddress(username));
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(to));
           message.setSubject(subject);
           message.setText(msg);
           Transport.send(message);
          b=true;
           
           
           
           
       }catch(Exception e){
           System.out.println("THE  EXCEPTION IS "+e);
       }
       return b;
}
}