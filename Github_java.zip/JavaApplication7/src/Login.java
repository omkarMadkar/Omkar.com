


public class Login extends javax.swing.JFrame {

    public Login() {
        initComponents();
        
        Internal_creat_account menu=new  Internal_creat_account();
        deskpane.removeAll();
        deskpane.add(menu).setVisible(true);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        SideBar = new javax.swing.JPanel();
        Logo = new javax.swing.JLabel();
        subHeading = new javax.swing.JLabel();
        CreateAccountBtn = new javax.swing.JPanel();
        Heading = new javax.swing.JLabel();
        LogoutBtn = new javax.swing.JLabel();
        ForgotPassBtn = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        deskpane = new javax.swing.JDesktopPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        SideBar.setBackground(new java.awt.Color(0, 20, 252));
        SideBar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        SideBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        SideBar.add(Logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(404, 33, -1, 33));

        subHeading.setForeground(new java.awt.Color(255, 255, 255));
        subHeading.setText("India's Number One Online Bank");
        SideBar.add(subHeading, new org.netbeans.lib.awtextra.AbsoluteConstraints(79, 271, 185, 44));

        CreateAccountBtn.setBackground(new java.awt.Color(0, 0, 255));
        CreateAccountBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        Heading.setFont(new java.awt.Font("Segoe UI Black", 0, 30)); // NOI18N
        Heading.setForeground(new java.awt.Color(255, 255, 255));
        Heading.setText("ASOD Bank");

        javax.swing.GroupLayout CreateAccountBtnLayout = new javax.swing.GroupLayout(CreateAccountBtn);
        CreateAccountBtn.setLayout(CreateAccountBtnLayout);
        CreateAccountBtnLayout.setHorizontalGroup(
            CreateAccountBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CreateAccountBtnLayout.createSequentialGroup()
                .addGap(81, 81, 81)
                .addComponent(Heading)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        CreateAccountBtnLayout.setVerticalGroup(
            CreateAccountBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CreateAccountBtnLayout.createSequentialGroup()
                .addGap(0, 13, Short.MAX_VALUE)
                .addComponent(Heading, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        SideBar.add(CreateAccountBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(4, 202, 260, -1));

        LogoutBtn.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        LogoutBtn.setForeground(new java.awt.Color(255, 255, 255));
        LogoutBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assest/white-close-icon.png"))); // NOI18N
        LogoutBtn.setText("Exit");
        LogoutBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        LogoutBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LogoutBtnMouseClicked(evt);
            }
        });
        SideBar.add(LogoutBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 520, 210, 40));

        ForgotPassBtn.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        ForgotPassBtn.setForeground(new java.awt.Color(255, 255, 255));
        ForgotPassBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assest/white-addAccount.png"))); // NOI18N
        ForgotPassBtn.setText("Create Account");
        ForgotPassBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        ForgotPassBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ForgotPassBtnMouseClicked(evt);
            }
        });
        SideBar.add(ForgotPassBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 420, 210, 40));

        jButton3.setBackground(new java.awt.Color(0, 20, 252));
        jButton3.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assest/white-forgetpass.png"))); // NOI18N
        jButton3.setText("Forget Password");
        jButton3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        SideBar.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 470, 210, 40));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assest/pngwing.com.png"))); // NOI18N

        javax.swing.GroupLayout deskpaneLayout = new javax.swing.GroupLayout(deskpane);
        deskpane.setLayout(deskpaneLayout);
        deskpaneLayout.setHorizontalGroup(
            deskpaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 498, Short.MAX_VALUE)
        );
        deskpaneLayout.setVerticalGroup(
            deskpaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(102, 102, 102)
                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE)
                .addGap(61, 61, 61)
                .addComponent(deskpane)
                .addGap(36, 36, 36))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(SideBar, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(534, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addComponent(jLabel4)
                .addContainerGap(400, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(deskpane)
                .addContainerGap())
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(SideBar, javax.swing.GroupLayout.DEFAULT_SIZE, 587, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
public void stop()
{
    deskpane.removeAll();
    this.dispose();
}
    private void LogoutBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutBtnMouseClicked
        Internal_creat_account menu=new  Internal_creat_account();
        deskpane.removeAll();
        deskpane.add(menu).setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_LogoutBtnMouseClicked

    private void ForgotPassBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ForgotPassBtnMouseClicked
       Creat_Account  menu=new   Creat_Account();
        deskpane.removeAll();
        deskpane.add(menu).setVisible(true);     // TODO add your handling code here:
    }//GEN-LAST:event_ForgotPassBtnMouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        this.dispose();
        forget menu=new  forget();

        menu.setVisible(true);

    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
      //
      //  java.awt.EventQueue.invokeLater(new Runnable() {
           // public void run() {
             //   new Login().setVisible(true);
          //  }
      //  });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel CreateAccountBtn;
    private javax.swing.JLabel ForgotPassBtn;
    private javax.swing.JLabel Heading;
    private javax.swing.JLabel Logo;
    private javax.swing.JLabel LogoutBtn;
    private javax.swing.JPanel SideBar;
    private javax.swing.JDesktopPane deskpane;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel subHeading;
    // End of variables declaration//GEN-END:variables
}
